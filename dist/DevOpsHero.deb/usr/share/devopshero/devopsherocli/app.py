"""Main Textual TUI Application for DevOpsHeroCLI."""
from __future__ import annotations

import time
from typing import Optional

from rich.markup import escape
from rich.panel import Panel
from rich.text import Text
from textual import on
from textual.app import App, ComposeResult
from textual.binding import Binding
from textual.containers import Horizontal, Vertical, VerticalScroll
from textual.screen import ModalScreen
from textual.widgets import (
    Button,
    Input,
    Label,
    ProgressBar,
    RichLog,
    Static,
)

from devopsherocli.compat import (
    ensure_utf8_encoding,
    get_powershell_humor_message,
    is_powershell,
)
from devopsherocli.engine.executor import CommandExecutor, EnvironmentState
from devopsherocli.models import Mission, UserProgress
from devopsherocli.tracks import ALL_TRACKS, TRACKS_MAP, get_mission, get_next_mission

ensure_utf8_encoding()


class TracksModal(ModalScreen):
    """Modal dialog displaying all tracks and mission selector."""

    def __init__(self, progress: UserProgress):
        super().__init__()
        self.progress = progress

    def compose(self) -> ComposeResult:
        with Vertical(id="tracks-dialog"):
            yield Label("🗺️ Trilhas de Aprendizado — Escolha uma Missão", classes="track-modal-header")
            with VerticalScroll(id="tracks-list"):
                for track in ALL_TRACKS:
                    completed_count = sum(1 for m in track.missions if m.id in self.progress.completed_missions)
                    total_count = len(track.missions)
                    yield Label(f"\n{track.icon} {track.name} ({completed_count}/{total_count} Concluídas) — {track.description}", classes="track-group-title")
                    for m in track.missions:
                        is_done = m.id in self.progress.completed_missions
                        is_curr = m.id == self.progress.current_mission_id
                        status_ico = "✅" if is_done else ("👉" if is_curr else "⭕")
                        btn_label = f"{status_ico} [{m.id}] {m.title} ({m.difficulty} · {m.xp} XP)"
                        btn_classes = "mission-item-btn " + ("mission-item-done" if is_done else ("mission-item-curr" if is_curr else ""))
                        btn = Button(btn_label, id=f"sel_m_{m.track_id}_{m.id}", classes=btn_classes)
                        yield btn
            yield Button("Fechar (Esc)", id="btn-close-modal")

    def on_button_pressed(self, event: Button.Pressed) -> None:
        btn_id = event.button.id or ""
        if btn_id == "btn-close-modal":
            self.dismiss(None)
        elif btn_id.startswith("sel_m_"):
            parts = btn_id.replace("sel_m_", "").split("_")
            track_id = parts[0]
            mission_id = "_".join(parts[1:])
            self.dismiss((track_id, mission_id))


class DevOpsHeroApp(App):
    """Full-featured Terminal User Interface for DevOpsHeroCLI."""

    CSS_PATH = "styles/devopshero.tcss"

    BINDINGS = [
        Binding("f1", "help", "Ajuda", show=True),
        Binding("f2", "tracks", "Trilhas (F2)", show=True),
        Binding("f3", "toggle_tip", "Dica (F3)", show=True),
        Binding("f4", "solution", "Gabarito (F4)", show=True),
        Binding("f5", "reset_lab", "Reset Lab (F5)", show=True),
        Binding("ctrl+l", "clear_screen", "Limpar", show=False),
        Binding("ctrl+q", "quit", "Sair", show=True),
    ]

    def __init__(self):
        super().__init__()
        self.progress = UserProgress()
        self.state = EnvironmentState()
        self.executor = CommandExecutor(self.state)
        self.current_mission: Optional[Mission] = None
        self.show_tip: bool = False
        self.show_solution: bool = False
        self.mission_start_time: float = time.time()
        self.tips_used: int = 0
        self.solution_used: bool = False
        self.last_command_success: bool = True

    def compose(self) -> ComposeResult:
        # Top Header Bar
        with Horizontal(id="header-bar"):
            yield Label("⚡ DEVOPS//HERO", classes="brand")
            with Vertical(classes="level-box"):
                yield Label("🌱 Lv.1 · 0 XP", id="lbl-level", classes="level-title")
                yield ProgressBar(total=100, show_eta=False, id="xp-bar", classes="xp-bar-container")
            yield Label("⚡ STREAK: 0", id="lbl-streak", classes="streak-box")
            with Horizontal(classes="nav-actions"):
                yield Button("🗺️ Trilhas", id="btn-tracks", classes="action-btn")
                yield Button("💡 Dica", id="btn-tip", classes="action-btn")
                yield Button("👁️ Solução", id="btn-solution", classes="action-btn")
                yield Button("🧹 Reset", id="btn-reset", classes="action-btn")

        # Main Body (Split into Mission Card & Terminal Screen)
        with Horizontal(id="main-container"):
            with VerticalScroll(id="mission-panel"):
                yield Label("// TRILHA: LINUX ESSENCIAL", id="lbl-mission-track", classes="mission-track-badge")
                yield Label("Missão 1: Navegação Básica", id="lbl-mission-title", classes="mission-title")
                with Horizontal(classes="meta-row"):
                    yield Label("Iniciante", id="lbl-diff-badge", classes="badge-diff")
                    yield Label("+100 XP", id="lbl-xp-badge", classes="badge-xp")
                    yield Label("⚡ 100% até 5s", id="lbl-speed-badge", classes="badge-speed")

                yield Label("// CENÁRIO REAL", classes="section-label")
                yield Static("", id="box-context", classes="context-box")

                yield Label("// OBJETIVO DA MISSÃO", classes="section-label")
                yield Static("", id="box-objective", classes="objective-box")

                yield Label("// SPEED SCORE (ANTI-COLA)", classes="section-label")
                yield Static(
                    "⚡ [bold #fbbf24]100% XP[/]: Envie sem dicas nos primeiros [bold #00ff87]5 segundos[/]!\n"
                    "⏱️ [dim]> 5 segundos sem dicas: 70% XP (tempo para busca externa)[/]\n"
                    "💡 [dim #fbbf24]A cada dica usada: pontuação reduzida (-60%, -80%...)[/]",
                    id="box-rules",
                    classes="rules-box",
                )

                yield Static("", id="box-tip", classes="tip-box")
                yield Static("", id="box-solution", classes="solution-box")

            with Vertical(id="terminal-panel"):
                with Horizontal(id="term-title-bar"):
                    yield Label("[#ff5f56]●[/] [#ffbd2e]●[/] [#27c93f]●[/]", classes="term-dots")
                    with Horizontal(classes="iterm-tab-active"):
                        yield Label("devops@ops-lab (zsh)", id="lbl-term-tab-title", classes="iterm-tab-title")
                    yield Static("", classes="term-bar-spacer")
                    yield Label("● ONLINE · 80x24", id="lbl-term-status-badge", classes="term-status-badge")
                yield RichLog(id="term-output-log", highlight=True, markup=True, wrap=True)
                with Horizontal(id="term-input-container"):
                    yield Label("➜  ~ ", id="term-prompt")
                    yield Input(placeholder="Digite aqui (ex: ls, pwd, git status, docker ps, kubectl get...)", id="term-input")

        with Horizontal(id="footer-bar"):
            yield Label("[bold #00f2fe]F2[/] Trilhas  │  [bold #fbbf24]F3[/] Dica  │  [bold #fb7185]F4[/] Solução  │  [bold #94a3b8]F5[/] Reset  │  [bold #00f2fe]Ctrl+L[/] Limpar  │  [bold #64748b]Ctrl+Q[/] Sair")

    def on_mount(self) -> None:
        if is_powershell():
            try:
                self.query_one("#lbl-term-tab-title", Label).update("🐚 devops@ops-lab (pwsh · em reabilitação 😉)")
                self.query_one("#lbl-term-status-badge", Label).update("PowerShell? · 80x24")
            except Exception:
                pass
        self.load_active_mission()
        self.update_header_stats()
        self.update_prompt()
        self.print_welcome_message()
        self.query_one("#term-input", Input).focus()

    def load_active_mission(self) -> None:
        track_id = self.progress.current_track_id
        mission_id = self.progress.current_mission_id
        self.current_mission = get_mission(track_id, mission_id) or ALL_TRACKS[0].missions[0]

        # Execute setup if any
        if self.current_mission.initial_setup:
            self.current_mission.initial_setup(self.state)

        self.show_tip = False
        self.show_solution = False
        self.tips_used = 0
        self.solution_used = False
        self.mission_start_time = time.time()
        self.render_mission_panel()

    def render_mission_panel(self) -> None:
        if not self.current_mission:
            return
        m = self.current_mission
        track = TRACKS_MAP.get(m.track_id)
        track_name = track.name if track else m.track_id

        self.query_one("#lbl-mission-track", Label).update(f"// TRILHA: {track_name.upper()}")
        self.query_one("#lbl-mission-title", Label).update(m.title)
        self.query_one("#lbl-diff-badge", Label).update(m.difficulty.upper())
        self.query_one("#lbl-xp-badge", Label).update(f"+{m.xp} XP")

        self.query_one("#box-context", Static).update(m.context)
        self.query_one("#box-objective", Static).update(f"🎯 {m.objective}")

        # Tip box
        tip_box = self.query_one("#box-tip", Static)
        if self.show_tip:
            tip_box.display = True
            tip_box.update(f"💡 [bold #fbbf24]DICA:[/] {m.tip}")
        else:
            tip_box.display = False

        # Solution box
        sol_box = self.query_one("#box-solution", Static)
        if self.show_solution:
            sol_box.display = True
            sol_box.update(f"👁️ [bold #fb7185]GABARITO:[/] [bold #00f2fe]{m.solution}[/]")
        else:
            sol_box.display = False

    def update_header_stats(self) -> None:
        lvl, title, icon, min_xp, next_xp = self.progress.get_level_info()
        xp_span = max(1, next_xp - min_xp)
        xp_curr = max(0, self.progress.xp - min_xp)
        pct = min(100, int((xp_curr / xp_span) * 100))

        self.query_one("#lbl-level", Label).update(f"{icon} Lv.{lvl} · {self.progress.xp} XP")
        self.query_one("#xp-bar", ProgressBar).update(progress=pct)

        bonus = self.progress.get_streak_bonus_pct()
        streak_txt = f"⚡ STREAK: {self.progress.streak}" + (f" (+{bonus}%)" if bonus > 0 else "")
        self.query_one("#lbl-streak", Label).update(streak_txt)

    def get_ohmyzsh_prompt(self, success: bool = True) -> str:
        arrow_color = "#00ff87" if success else "#fb7185"
        cwd = self.state.linux.cwd.replace("/home/devops", "~")

        git_segment = ""
        if self.state.git.is_repo:
            branch = self.state.git.current_branch or "main"
            is_dirty = bool(self.state.git.staged_files or self.state.git.unstaged_files or self.state.git.untracked_files)
            dirty_sym = " [bold #fbbf24]✗[/]" if is_dirty else ""
            git_segment = f" [bold #00f2fe]git:([/][bold #fb7185]{branch}[/]{dirty_sym}[bold #00f2fe])[/]"
        elif "git" in self.state.linux.cwd:
            git_segment = " [bold #00f2fe]git:([/][bold #fb7185]main[/][bold #00f2fe])[/]"

        return f"[bold {arrow_color}]➜[/]  [bold #38bdf8]{cwd}[/]{git_segment} "

    def update_prompt(self) -> None:
        prompt_markup = self.get_ohmyzsh_prompt(self.last_command_success)
        self.query_one("#term-prompt", Label).update(prompt_markup)

    def print_welcome_message(self) -> None:
        log = self.query_one("#term-output-log", RichLog)
        cur_time = time.strftime("%a %b %d %H:%M:%S")
        log.write(f"[dim #64748b]Last login: {cur_time} on ttys001 (iTerm2)[/]")

        if is_powershell():
            log.write(Panel(
                get_powershell_humor_message(),
                title="[bold #fbbf24]⚠️  PowerShell Easter Egg[/]",
                border_style="#fbbf24",
            ))
            self.notify(
                "Você realmente chama isso de terminal?! 😂 Recomendamos um de verdade longe do Windows... Mas relaxa, o DevOpsHero roda suave até aqui!",
                title="⚠️ PowerShell Detectado!",
                severity="warning",
                timeout=8.0,
            )

        omz_lines = [
            "         __                                     __",
            "  ____  / /_     ____ ___  __  __   ____  _____/ /_",
            " / __ \\/ __ \\   / __ `__ \\/ / / /  /_  / / ___/ __ \\",
            "/ /_/ / / / /  / / / / / / /_/ /    / /_(__  ) / / /",
            "\\____/_/ /_/  /_/ /_/ /_/\\__, /    /___/____/_/ /_/",
            "                        /____/     v5.9 (iTerm2 · Oh My Zsh)",
        ]
        for line in omz_lines:
            log.write(Text(line, style="bold #00ff87"))
        log.write("[#64748b]• Theme: [bold #fbbf24]robbyrussell[/]  │  Plugins: [bold #38bdf8]git[/], [bold #38bdf8]docker[/], [bold #38bdf8]kubectl[/], [bold #38bdf8]aws[/], [bold #38bdf8]terraform[/], [bold #38bdf8]datadog[/][/]")
        log.write("[#64748b]• Comandos: [bold #00f2fe]'h'[/]elp, [bold #fbbf24]'d'[/]ica, [bold #fb7185]'s'[/]olução, [bold #00ff87]'r'[/]eset, [bold #00f2fe]'t'[/]rilhas, [bold #00ff87]'n'[/]ext[/]\n")

    @on(Input.Submitted, "#term-input")
    def handle_terminal_input(self, event: Input.Submitted) -> None:
        cmd_text = event.value.strip()
        inp = self.query_one("#term-input", Input)
        inp.value = ""

        if not cmd_text:
            return

        self.progress.command_history.append(cmd_text)
        log = self.query_one("#term-output-log", RichLog)

        # Print prompt line in authentic Oh My Zsh style
        prompt_markup = self.get_ohmyzsh_prompt(self.last_command_success)
        log.write(f"{prompt_markup}[bold #ffffff]{escape(cmd_text)}[/]")

        # Handle built-in meta commands
        lower_cmd = cmd_text.lower()
        if lower_cmd == "help":
            self.last_command_success = True
            log.write(
                "[bold yellow]Comandos de apoio do DevOpsHeroCLI:[/]\n"
                "  [bold cyan]dica[/]       - Revela a dica da missão atual (F3)\n"
                "  [bold cyan]solucao[/]    - Revela o comando gabarito da missão (F4 - zera streak)\n"
                "  [bold cyan]trilhas[/]    - Abre a seleção de trilhas e missões (F2)\n"
                "  [bold cyan]reset[/]      - Restaura o ambiente da missão atual para o estado inicial\n"
                "  [bold cyan]clear[/]      - Limpa a tela do terminal (Ctrl+L)\n"
                "  [bold cyan]stats[/]      - Mostra seu perfil, XP e conquistas\n"
                "  [bold cyan]proxima[/]    - Pula para a próxima missão\n"
            )
            self.update_prompt()
            return
        elif lower_cmd in ["dica", "hint"]:
            self.last_command_success = True
            self.action_toggle_tip()
            self.update_prompt()
            return
        elif lower_cmd in ["solucao", "solution", "gabarito"]:
            self.last_command_success = True
            self.action_solution()
            self.update_prompt()
            return
        elif lower_cmd in ["trilhas", "tracks"]:
            self.last_command_success = True
            self.action_tracks()
            self.update_prompt()
            return
        elif lower_cmd == "reset":
            self.last_command_success = True
            self.action_reset_lab()
            self.update_prompt()
            return
        elif lower_cmd == "clear":
            self.last_command_success = True
            self.action_clear_screen()
            self.update_prompt()
            return
        elif lower_cmd in ["stats", "perfil"]:
            self.last_command_success = True
            self.show_user_stats(log)
            self.update_prompt()
            return
        elif lower_cmd in ["proxima", "next"]:
            self.last_command_success = True
            self.advance_to_next_mission()
            self.update_prompt()
            return

        # Execute in simulated engine
        output = self.executor.execute_command_string(cmd_text)
        if output:
            try:
                log.write(output)
            except Exception:
                log.write(Text(output))
            low_out = output.lower()
            if "command not found" in low_out or "error" in low_out or "fatal" in low_out:
                self.last_command_success = False
            else:
                self.last_command_success = True
        else:
            self.last_command_success = True

        self.update_prompt()

        # Check mission completion
        if self.current_mission and self.current_mission.check_completion:
            completed, feedback = self.current_mission.check_completion(self.state, cmd_text, output)
            if completed:
                elapsed = max(0.1, round(time.time() - self.mission_start_time, 1))
                award = self.progress.award_mission(
                    self.current_mission,
                    elapsed_seconds=elapsed,
                    tips_used=self.tips_used,
                    solution_used=self.solution_used,
                )
                self.update_header_stats()

                # Bell ring & celebratory banner
                self.bell()
                log.write("")
                log.write("[bold #30d158]╭─────────────────────────────────────────────────────────────────╮[/]")
                log.write("[bold #30d158]│[/] [bold #ffffff]🎉 PARABÉNS! MISSÃO CONCLUÍDA COM SUCESSO![/]")
                log.write(f"[bold #30d158]│[/] [bold #ffd60a]+{award.xp} XP Conquistados![/] · {award.tier_name}")
                log.write(f"[bold #30d158]│[/] ⏱️ [bold cyan]Tempo:[/] {elapsed}s  │  💡 [bold yellow]Dicas:[/] {self.tips_used}  │  🔥 [bold #ff453a]Streak:[/] {self.progress.streak} (+{award.streak_bonus_pct}%)")
                if award.is_ninja:
                    log.write("[bold #30d158]│[/] [bold #30d158]⚡ 100% DOS PONTOS! Executado em <5s sem dicas ou cola de IA![/]")
                elif self.tips_used > 0:
                    log.write(f"[bold #30d158]│[/] [dim yellow]⚠️ Dicas utilizadas: Pontuação reduzida ({int(award.factor*100)}% de XP).[/]")
                elif elapsed > 5.0:
                    log.write("[bold #30d158]│[/] [dim]ℹ️ Tempo > 5s: 70% de XP (Regra anti-cola de Google/IA).[/]")
                log.write("[bold #30d158]╰─────────────────────────────────────────────────────────────────╯[/]")
                log.write("[dim]Avançando para a próxima missão...[/]\n")

                # Auto advance
                self.set_timer(2.2, self.advance_to_next_mission)

    def advance_to_next_mission(self) -> None:
        if not self.current_mission:
            return
        next_step = get_next_mission(self.current_mission.track_id, self.current_mission.id)
        if next_step:
            t_id, m_id = next_step
            self.progress.current_track_id = t_id
            self.progress.current_mission_id = m_id
            self.progress.save()
            self.load_active_mission()

            log = self.query_one("#term-output-log", RichLog)
            log.write(f"[bold #ffd60a]👉 Nova Missão:[/] [bold #5ac8fa]{self.current_mission.title}[/]")
            log.write("[dim]Confira os objetivos e detalhes no painel à esquerda.[/dim]\n")
        else:
            log = self.query_one("#term-output-log", RichLog)
            log.write("[bold gold1]🏆 PARABÉNS! VOCÊ COMPLETOU TODAS AS MISSÕES DO DEVOPSHEROCLI![/]")

    def show_user_stats(self, log: RichLog) -> None:
        lvl, title, icon, min_xp, next_xp = self.progress.get_level_info()
        completed = len(self.progress.completed_missions)
        total = sum(len(t.missions) for t in ALL_TRACKS)
        log.write(
            f"[bold cyan]Perfil DevOps do Usuário:[/]\n"
            f"  {icon} [bold]{title}[/]\n"
            f"  ⭐ XP Total: {self.progress.xp} XP\n"
            f"  🔥 Streak Atual: {self.progress.streak} (Recorde: {self.progress.max_streak})\n"
            f"  ✅ Missões Concluídas: {completed} / {total}\n"
        )

    # Actions & Buttons
    def action_tracks(self) -> None:
        def on_selection(result):
            if result:
                track_id, mission_id = result
                self.progress.current_track_id = track_id
                self.progress.current_mission_id = mission_id
                self.progress.save()
                self.load_active_mission()

        self.push_screen(TracksModal(self.progress), on_selection)

    def action_toggle_tip(self) -> None:
        self.show_tip = not self.show_tip
        if self.show_tip:
            self.tips_used += 1
            log = self.query_one("#term-output-log", RichLog)
            log.write(f"[dim yellow]💡 Dica revelada (Uso #{self.tips_used})! Atenção: o uso de dicas reduz o XP da missão.[/]")
        self.render_mission_panel()

    def action_solution(self) -> None:
        self.show_solution = True
        self.solution_used = True
        self.progress.break_streak()
        self.update_header_stats()
        self.render_mission_panel()
        log = self.query_one("#term-output-log", RichLog)
        log.write("[bold #ff3b30]👁️ Gabarito revelado![/] [dim yellow]O XP desta missão foi zerado e o streak resetado.[/]")

    def action_reset_lab(self) -> None:
        self.state.reset_all()
        if self.current_mission and self.current_mission.initial_setup:
            self.current_mission.initial_setup(self.state)
        self.mission_start_time = time.time()
        self.tips_used = 0
        self.solution_used = False
        log = self.query_one("#term-output-log", RichLog)
        log.write("[bold green]🧹 Ambiente simulado restaurado para o estado inicial. Cronômetro zerado![/]")

    def action_clear_screen(self) -> None:
        log = self.query_one("#term-output-log", RichLog)
        log.clear()

    @on(Button.Pressed, "#btn-tracks")
    def on_btn_tracks(self) -> None:
        self.action_tracks()

    @on(Button.Pressed, "#btn-tip")
    def on_btn_tip(self) -> None:
        self.action_toggle_tip()

    @on(Button.Pressed, "#btn-solution")
    def on_btn_solution(self) -> None:
        self.action_solution()

    @on(Button.Pressed, "#btn-reset")
    def on_btn_reset(self) -> None:
        self.action_reset_lab()


def launch_app():
    app = DevOpsHeroApp()
    app.run()


if __name__ == "__main__":
    launch_app()
